import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Label } from '@/components/ui/label.jsx'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx'
import { Textarea } from '@/components/ui/textarea.jsx'
import { Slider } from '@/components/ui/slider.jsx'
import { Switch } from '@/components/ui/switch.jsx'
import { Copy, Shuffle, Trash2, Sparkles } from 'lucide-react'
import './App.css'

function App() {
  // Estados para os dados das opções
  const [options, setOptions] = useState({
    subjects: [],
    styles: [],
    compositions: [],
    aspectRatios: [],
    moods: [],
    qualityLevels: [],
    lightingOptions: [],
    famousArtists: [],
    cameras: [],
    aiPlatforms: {}
  })

  // Estados para o formulário
  const [formData, setFormData] = useState({
    subject: '',
    customDetails: '',
    style: '',
    composition: '',
    quality: '',
    aiPlatform: 'midjourney',
    mood: '',
    aspectRatio: '1:1',
    artist: '',
    lighting: '',
    camera: '',
    creativity: [50],
    negativePrompt: ''
  })

  // Estados da interface
  const [advancedMode, setAdvancedMode] = useState(false)
  const [generatedPrompt, setGeneratedPrompt] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const [currentPlatform, setCurrentPlatform] = useState('Midjourney')

  // Carregar opções do backend
  useEffect(() => {
    fetchOptions()
  }, [])

  const fetchOptions = async () => {
    try {
      const response = await fetch('http://localhost:5001/api/prompts/options')
      const data = await response.json()
      setOptions(data)
    } catch (error) {
      console.error('Erro ao carregar opções:', error)
    }
  }

  const handleInputChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }))
    
    // Atualizar nome da plataforma quando mudar
    if (field === 'aiPlatform') {
      setCurrentPlatform(options.aiPlatforms[value]?.name || value)
    }
  }

  const generatePrompt = async () => {
    setIsLoading(true)
    try {
      const response = await fetch('http://localhost:5001/api/prompts/generate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ...formData,
          creativity: formData.creativity[0]
        })
      })
      
      const data = await response.json()
      setGeneratedPrompt(data.prompt)
      setCurrentPlatform(data.platform)
    } catch (error) {
      console.error('Erro ao gerar prompt:', error)
    } finally {
      setIsLoading(false)
    }
  }

  const generateRandom = async () => {
    try {
      const response = await fetch('http://localhost:5001/api/prompts/random')
      const data = await response.json()
      setFormData(prev => ({
        ...prev,
        ...data,
        creativity: [data.creativity]
      }))
      setCurrentPlatform(options.aiPlatforms[data.aiPlatform]?.name || data.aiPlatform)
    } catch (error) {
      console.error('Erro ao gerar configuração aleatória:', error)
    }
  }

  const copyToClipboard = () => {
    navigator.clipboard.writeText(generatedPrompt)
  }

  const clearForm = () => {
    setFormData({
      subject: '',
      customDetails: '',
      style: '',
      composition: '',
      quality: '',
      aiPlatform: 'midjourney',
      mood: '',
      aspectRatio: '1:1',
      artist: '',
      lighting: '',
      camera: '',
      creativity: [50],
      negativePrompt: ''
    })
    setGeneratedPrompt('')
    setCurrentPlatform('Midjourney')
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-blue-50 p-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-2 flex items-center justify-center gap-2">
            <Sparkles className="text-purple-600" />
            Gerador de Prompts de Imagem IA
          </h1>
          <p className="text-gray-600 text-lg">
            Crie prompts otimizados para múltiplas plataformas de IA
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Formulário Principal */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Configurações do Prompt</CardTitle>
                    <CardDescription>
                      Configure os parâmetros para gerar seu prompt personalizado
                    </CardDescription>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Label htmlFor="advanced-mode">Modo Avançado</Label>
                    <Switch
                      id="advanced-mode"
                      checked={advancedMode}
                      onCheckedChange={setAdvancedMode}
                    />
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="basic" className="w-full">
                  <TabsList className="grid w-full grid-cols-3">
                    <TabsTrigger value="basic">Básico</TabsTrigger>
                    <TabsTrigger value="style">Estilo</TabsTrigger>
                    <TabsTrigger value="technical">Técnico</TabsTrigger>
                  </TabsList>

                  {/* Aba Básico */}
                  <TabsContent value="basic" className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="subject">Assunto Principal</Label>
                        <Select value={formData.subject} onValueChange={(value) => handleInputChange('subject', value)}>
                          <SelectTrigger>
                            <SelectValue placeholder="Selecione o assunto" />
                          </SelectTrigger>
                          <SelectContent>
                            {options.subjects.map(subject => (
                              <SelectItem key={subject} value={subject}>{subject}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      <div>
                        <Label htmlFor="aiPlatform">Plataforma de IA</Label>
                        <Select value={formData.aiPlatform} onValueChange={(value) => handleInputChange('aiPlatform', value)}>
                          <SelectTrigger>
                            <SelectValue placeholder="Selecione a plataforma" />
                          </SelectTrigger>
                          <SelectContent>
                            {Object.entries(options.aiPlatforms).map(([key, platform]) => (
                              <SelectItem key={key} value={key}>{platform.name}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="customDetails">Detalhes Personalizados</Label>
                      <Textarea
                        id="customDetails"
                        placeholder="Descreva detalhes específicos do que você quer gerar..."
                        value={formData.customDetails}
                        onChange={(e) => handleInputChange('customDetails', e.target.value)}
                        className="min-h-[100px]"
                      />
                    </div>
                  </TabsContent>

                  {/* Aba Estilo */}
                  <TabsContent value="style" className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="style">Estilo Artístico</Label>
                        <Select value={formData.style} onValueChange={(value) => handleInputChange('style', value)}>
                          <SelectTrigger>
                            <SelectValue placeholder="Selecione o estilo" />
                          </SelectTrigger>
                          <SelectContent>
                            {options.styles.map(style => (
                              <SelectItem key={style} value={style}>{style}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      <div>
                        <Label htmlFor="mood">Humor/Tom</Label>
                        <Select value={formData.mood} onValueChange={(value) => handleInputChange('mood', value)}>
                          <SelectTrigger>
                            <SelectValue placeholder="Selecione o humor" />
                          </SelectTrigger>
                          <SelectContent>
                            {options.moods.map(mood => (
                              <SelectItem key={mood} value={mood}>{mood}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    {advancedMode && (
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="artist">Artista de Referência</Label>
                          <Select value={formData.artist} onValueChange={(value) => handleInputChange('artist', value)}>
                            <SelectTrigger>
                              <SelectValue placeholder="Selecione um artista" />
                            </SelectTrigger>
                            <SelectContent>
                              {options.famousArtists.map(artist => (
                                <SelectItem key={artist} value={artist}>{artist}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>

                        <div>
                          <Label htmlFor="lighting">Iluminação</Label>
                          <Select value={formData.lighting} onValueChange={(value) => handleInputChange('lighting', value)}>
                            <SelectTrigger>
                              <SelectValue placeholder="Selecione a iluminação" />
                            </SelectTrigger>
                            <SelectContent>
                              {options.lightingOptions.map(lighting => (
                                <SelectItem key={lighting} value={lighting}>{lighting}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                    )}
                  </TabsContent>

                  {/* Aba Técnico */}
                  <TabsContent value="technical" className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="composition">Composição</Label>
                        <Select value={formData.composition} onValueChange={(value) => handleInputChange('composition', value)}>
                          <SelectTrigger>
                            <SelectValue placeholder="Selecione a composição" />
                          </SelectTrigger>
                          <SelectContent>
                            {options.compositions.map(composition => (
                              <SelectItem key={composition} value={composition}>{composition}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      <div>
                        <Label htmlFor="aspectRatio">Proporção</Label>
                        <Select value={formData.aspectRatio} onValueChange={(value) => handleInputChange('aspectRatio', value)}>
                          <SelectTrigger>
                            <SelectValue placeholder="Selecione a proporção" />
                          </SelectTrigger>
                          <SelectContent>
                            {options.aspectRatios.map(ratio => (
                              <SelectItem key={ratio} value={ratio}>{ratio}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="quality">Qualidade</Label>
                        <Select value={formData.quality} onValueChange={(value) => handleInputChange('quality', value)}>
                          <SelectTrigger>
                            <SelectValue placeholder="Selecione a qualidade" />
                          </SelectTrigger>
                          <SelectContent>
                            {options.qualityLevels.map(quality => (
                              <SelectItem key={quality} value={quality}>{quality}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      {advancedMode && (
                        <div>
                          <Label htmlFor="camera">Câmera</Label>
                          <Select value={formData.camera} onValueChange={(value) => handleInputChange('camera', value)}>
                            <SelectTrigger>
                              <SelectValue placeholder="Selecione a câmera" />
                            </SelectTrigger>
                            <SelectContent>
                              {options.cameras.map(camera => (
                                <SelectItem key={camera} value={camera}>{camera}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      )}
                    </div>

                    {advancedMode && (
                      <div>
                        <Label htmlFor="creativity">Nível de Criatividade: {formData.creativity[0]}%</Label>
                        <Slider
                          id="creativity"
                          min={0}
                          max={100}
                          step={10}
                          value={formData.creativity}
                          onValueChange={(value) => handleInputChange('creativity', value)}
                          className="mt-2"
                        />
                      </div>
                    )}

                    {advancedMode && (
                      <div>
                        <Label htmlFor="negativePrompt">Prompt Negativo</Label>
                        <Textarea
                          id="negativePrompt"
                          placeholder="Elementos que você NÃO quer na imagem..."
                          value={formData.negativePrompt}
                          onChange={(e) => handleInputChange('negativePrompt', e.target.value)}
                          className="min-h-[80px]"
                        />
                      </div>
                    )}
                  </TabsContent>
                </Tabs>

                {/* Botões de Ação */}
                <div className="flex flex-wrap gap-2 mt-6">
                  <Button onClick={generatePrompt} disabled={isLoading} className="flex-1 min-w-[120px]">
                    {isLoading ? 'Gerando...' : 'Gerar Prompt'}
                  </Button>
                  <Button onClick={generateRandom} variant="outline" className="flex items-center gap-2">
                    <Shuffle className="w-4 h-4" />
                    Aleatório
                  </Button>
                  <Button onClick={clearForm} variant="outline" className="flex items-center gap-2">
                    <Trash2 className="w-4 h-4" />
                    Limpar
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Resultado */}
          <div className="lg:col-span-1">
            <Card className="sticky top-4">
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  Prompt Gerado
                  <span className="text-sm font-normal text-gray-500">{currentPlatform}</span>
                </CardTitle>
                <CardDescription>
                  Seu prompt otimizado está pronto para uso
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <Textarea
                    value={generatedPrompt}
                    readOnly
                    placeholder="Seu prompt aparecerá aqui..."
                    className="min-h-[200px] font-mono text-sm"
                  />
                  
                  {generatedPrompt && (
                    <Button onClick={copyToClipboard} className="w-full flex items-center gap-2">
                      <Copy className="w-4 h-4" />
                      Copiar Prompt
                    </Button>
                  )}

                  {formData.negativePrompt && advancedMode && (
                    <div>
                      <Label>Prompt Negativo:</Label>
                      <Textarea
                        value={formData.negativePrompt}
                        readOnly
                        className="mt-2 min-h-[80px] font-mono text-sm"
                      />
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}

export default App

