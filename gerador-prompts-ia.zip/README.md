# Gerador de Prompts de Imagem IA

## Descrição

O **Gerador de Prompts de Imagem IA** é uma aplicação web completa que permite aos usuários criar prompts de imagem detalhados e otimizados para múltiplas plataformas de inteligência artificial, incluindo Midjourney, Leonardo.ai, Veo 3, Chat GPT (DALL-E 3) e Gemini (Imagen 3).

## Características Implementadas

### 🎨 Interface Intuitiva
- Design moderno e responsivo com Tailwind CSS
- Interface organizada em abas para fácil navegação (Básico, Estilo, Técnico)
- Modo avançado com controles adicionais
- Feedback visual imediato para todas as seleções

### 🤖 Suporte Multi-Plataforma
- **Midjourney**: Parâmetros específicos como `--ar`, `--v`, `--style`, `--stylize`
- **Leonardo.ai**: Configurações de Alchemy, PhotoReal, Guidance Scale
- **Veo 3**: Otimizações para geração de vídeo e movimento
- **Chat GPT**: Formatação específica para DALL-E 3
- **Gemini**: Configurações para Imagen 3 do Google

### 📊 Categorias Abrangentes

#### 1. Assunto Principal
- 12 categorias: Pessoa, Animal, Paisagem, Objeto, Arquitetura, Veículo, Fantasia, Sci-fi, Natureza, Retrato, Cena urbana, Espaço
- Campo de detalhes customizados para especificações únicas

#### 2. Estilo Artístico
- 15 estilos: Fotorrealista, Pintura a óleo, Aquarela, Arte digital, Anime, Cartoon, 3D render, Pixel art, Impressionista, Surrealista, Cyberpunk, Steampunk, Art nouveau, Pop art, Minimalista
- Seleção de artistas famosos no modo avançado

#### 3. Composição e Enquadramento
- 12 tipos de composição: Close-up, Plano médio, Plano geral, Vista aérea, Ângulo baixo, Ângulo alto, Regra dos terços, Simetria, Perspectiva isométrica, Profundidade de campo rasa, Grande angular, Macro
- 7 proporções de imagem disponíveis
- Configurações de iluminação no modo avançado
- Seleção de câmeras profissionais

#### 4. Detalhes e Qualidade
- 12 opções de humor/tom
- 10 configurações de qualidade
- Controle deslizante de criatividade (modo avançado)
- Campo para prompts negativos

### 🔧 Funcionalidades Avançadas

#### Modo Avançado
- Seleção de artistas e referências
- Configurações de iluminação específicas
- Controle de câmeras profissionais
- Slider de criatividade (0-100%)

#### Geração Inteligente
- Algoritmo que adapta o prompt para cada plataforma de IA
- Geração aleatória para inspiração
- Otimização automática baseada no nível de criatividade
- Formatação específica para cada ferramenta

#### Interface de Resultado
- Visualização em tempo real do prompt gerado
- Botão de cópia com um clique
- Função de limpeza rápida
- Indicação da plataforma selecionada

## Arquitetura Técnica

### Frontend
- **React.js** com Vite para desenvolvimento rápido
- **Tailwind CSS** para estilização moderna e responsiva
- **shadcn/ui** para componentes de interface consistentes
- **Lucide React** para ícones

### Backend
- **Flask** (Python) para API REST
- **Flask-CORS** para comunicação cross-origin
- Algoritmos de otimização de prompts específicos por plataforma
- Estrutura modular com blueprints

## Como Executar

### Pré-requisitos
- Python 3.11+
- Node.js 20+
- pnpm

### Backend (Flask)
```bash
cd gerador-prompts-backend
source venv/bin/activate
pip install -r requirements.txt
python src/main.py
```

### Frontend (React)
```bash
cd gerador-prompts-frontend
pnpm install
pnpm run dev --host
```

### Acessar a Aplicação
- Frontend: http://localhost:5173
- Backend API: http://localhost:5001

## Estrutura do Projeto

```
/
├── gerador-prompts-backend/     # API Flask
│   ├── src/
│   │   ├── routes/
│   │   │   ├── prompt_generator.py  # Lógica de geração de prompts
│   │   │   └── user.py
│   │   ├── models/
│   │   ├── static/              # Arquivos estáticos
│   │   └── main.py              # Ponto de entrada
│   ├── venv/                    # Ambiente virtual Python
│   └── requirements.txt
├── gerador-prompts-frontend/    # Interface React
│   ├── src/
│   │   ├── components/          # Componentes React
│   │   ├── App.jsx              # Componente principal
│   │   └── main.jsx
│   ├── public/
│   └── package.json
└── README.md
```

## Funcionalidades Testadas

✅ **Interface de usuário completa e responsiva**
✅ **Comunicação frontend-backend funcionando**
✅ **Geração de prompts otimizados por plataforma**
✅ **Sistema de abas (Básico, Estilo, Técnico)**
✅ **Modo avançado com controles adicionais**
✅ **Função de geração aleatória**
✅ **Botão de cópia de prompts**
✅ **Suporte a múltiplas plataformas de IA**

## Exemplo de Uso Testado

**Configuração:**
- Assunto: Pessoa
- Detalhes: "mulher jovem com cabelos cacheados, sorrindo, olhos verdes"
- Estilo: Fotorrealista
- Composição: Close-up
- Qualidade: Ultra detalhado
- IA: Midjourney

**Prompt Gerado:**
```
pessoa, mulher jovem com cabelos cacheados, sorrindo, olhos verdes, fotorrealista style, close-up, ultra detalhado --ar 1:1 --v 6.0 --stylize 500 --q 2
```

## Próximos Passos Sugeridos

Para expandir a aplicação, considere implementar:

1. **Histórico de prompts gerados**
2. **Salvamento de configurações favoritas**
3. **Exportação em múltiplos formatos**
4. **Integração com APIs das plataformas de IA**
5. **Galeria de exemplos com resultados**
6. **Sistema de templates personalizados**
7. **Análise de performance de prompts**

## Tecnologias Utilizadas

- **Frontend**: React, Vite, Tailwind CSS, shadcn/ui, Lucide React
- **Backend**: Flask, Python, Flask-CORS
- **Desenvolvimento**: Node.js, pnpm, Python venv
- **Arquitetura**: SPA (Single Page Application) com API REST

O aplicativo está totalmente funcional e pronto para uso, implementando todas as características principais descritas na documentação original.

