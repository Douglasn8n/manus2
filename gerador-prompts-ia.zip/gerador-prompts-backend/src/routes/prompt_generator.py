from flask import Blueprint, request, jsonify
from flask_cors import cross_origin

prompt_bp = Blueprint('prompt', __name__)

# Dados de configuração para as diferentes plataformas de IA
AI_PLATFORMS = {
    'midjourney': {
        'name': 'Midjourney',
        'parameters': ['--ar', '--v', '--style', '--stylize', '--q']
    },
    'leonardo': {
        'name': 'Leonardo.ai',
        'parameters': ['Alchemy', 'PhotoReal', 'Guidance Scale']
    },
    'veo3': {
        'name': 'Veo 3',
        'parameters': ['motion', 'duration', 'style']
    },
    'chatgpt': {
        'name': 'Chat GPT (DALL-E 3)',
        'parameters': ['style', 'quality', 'size']
    },
    'gemini': {
        'name': 'Gemini (Imagen 3)',
        'parameters': ['style', 'aspect_ratio', 'quality']
    }
}

# Categorias e opções disponíveis
SUBJECTS = [
    'Pessoa', 'Animal', 'Paisagem', 'Objeto', 'Arquitetura', 'Veículo',
    'Fantasia', 'Sci-fi', 'Natureza', 'Retrato', 'Cena urbana', 'Espaço'
]

STYLES = [
    'Fotorrealista', 'Pintura a óleo', 'Aquarela', 'Arte digital', 'Anime',
    'Cartoon', '3D render', 'Pixel art', 'Impressionista', 'Surrealista',
    'Cyberpunk', 'Steampunk', 'Art nouveau', 'Pop art', 'Minimalista'
]

COMPOSITIONS = [
    'Close-up', 'Plano médio', 'Plano geral', 'Vista aérea', 'Ângulo baixo',
    'Ângulo alto', 'Regra dos terços', 'Simetria', 'Perspectiva isométrica',
    'Profundidade de campo rasa', 'Grande angular', 'Macro'
]

ASPECT_RATIOS = ['1:1', '16:9', '9:16', '4:3', '3:4', '21:9', '2:3']

MOODS = [
    'Alegre', 'Melancólico', 'Dramático', 'Sereno', 'Misterioso',
    'Energético', 'Romântico', 'Sombrio', 'Épico', 'Nostálgico',
    'Futurista', 'Vintage'
]

QUALITY_LEVELS = [
    'Básico', 'Bom', 'Alto', 'Ultra detalhado', 'Fotorrealista',
    'Cinematográfico', 'Artístico', 'Profissional', 'Masterpiece', 'Award-winning'
]

LIGHTING_OPTIONS = [
    'Natural', 'Golden hour', 'Blue hour', 'Dramatic', 'Soft',
    'Hard', 'Neon', 'Candlelight', 'Studio', 'Backlit'
]

FAMOUS_ARTISTS = [
    'Leonardo da Vinci', 'Van Gogh', 'Picasso', 'Monet', 'Dali',
    'Warhol', 'Banksy', 'Frida Kahlo', 'Michelangelo', 'Rembrandt'
]

CAMERAS = [
    'Canon EOS R5', 'Nikon D850', 'Sony A7R IV', 'Fujifilm X-T4',
    'Leica M10', 'Hasselblad X1D', 'Phase One XF', 'RED Komodo'
]

@prompt_bp.route('/generate', methods=['POST'])
@cross_origin()
def generate_prompt():
    """Gera um prompt otimizado baseado nos parâmetros fornecidos"""
    try:
        data = request.get_json()
        
        # Parâmetros obrigatórios
        subject = data.get('subject', '')
        custom_details = data.get('customDetails', '')
        style = data.get('style', '')
        composition = data.get('composition', '')
        quality = data.get('quality', '')
        ai_platform = data.get('aiPlatform', 'midjourney')
        
        # Parâmetros opcionais
        mood = data.get('mood', '')
        aspect_ratio = data.get('aspectRatio', '1:1')
        artist = data.get('artist', '')
        lighting = data.get('lighting', '')
        camera = data.get('camera', '')
        creativity = data.get('creativity', 50)
        negative_prompt = data.get('negativePrompt', '')
        
        # Gerar o prompt base
        prompt_parts = []
        
        # Adicionar assunto e detalhes
        if subject:
            prompt_parts.append(subject.lower())
        if custom_details:
            prompt_parts.append(custom_details)
            
        # Adicionar modificadores de estilo
        if style:
            prompt_parts.append(f"{style.lower()} style")
        if artist:
            prompt_parts.append(f"by {artist}")
        if mood:
            prompt_parts.append(f"{mood.lower()} mood")
        if lighting:
            prompt_parts.append(f"{lighting.lower()} lighting")
            
        # Adicionar parâmetros técnicos
        if composition:
            prompt_parts.append(composition.lower())
        if camera:
            prompt_parts.append(f"shot with {camera}")
        if quality:
            prompt_parts.append(quality.lower())
            
        # Montar prompt base
        base_prompt = ", ".join(prompt_parts)
        
        # Otimizar para a plataforma específica
        optimized_prompt = optimize_for_platform(base_prompt, ai_platform, aspect_ratio, creativity)
        
        # Adicionar prompt negativo se fornecido
        result = {
            'prompt': optimized_prompt,
            'platform': AI_PLATFORMS.get(ai_platform, {}).get('name', ai_platform),
            'negative_prompt': negative_prompt if negative_prompt else None
        }
        
        return jsonify(result)
        
    except Exception as e:
        return jsonify({'error': str(e)}), 400

def optimize_for_platform(base_prompt, platform, aspect_ratio, creativity):
    """Otimiza o prompt para a plataforma específica de IA"""
    
    if platform == 'midjourney':
        # Parâmetros específicos do Midjourney
        params = []
        params.append(f"--ar {aspect_ratio}")
        params.append("--v 6.0")
        
        if creativity > 70:
            params.append("--style raw")
            params.append("--stylize 1000")
        elif creativity > 40:
            params.append("--stylize 500")
        else:
            params.append("--stylize 100")
            
        params.append("--q 2")
        
        return f"{base_prompt} {' '.join(params)}"
        
    elif platform == 'leonardo':
        # Parâmetros específicos do Leonardo.ai
        params = []
        if creativity > 60:
            params.append("[Alchemy, PhotoReal]")
        else:
            params.append("[Alchemy, High Quality]")
            
        guidance_scale = min(10, max(1, int(creativity / 10)))
        params.append(f"[Guidance Scale: {guidance_scale}]")
        
        return f"{base_prompt} {' '.join(params)}"
        
    elif platform == 'veo3':
        # Otimizações para Veo 3 (geração de vídeo)
        video_params = []
        video_params.append("cinematic movement")
        video_params.append("smooth transitions")
        if creativity > 50:
            video_params.append("dynamic camera work")
            
        return f"{base_prompt}, {', '.join(video_params)}"
        
    elif platform == 'chatgpt':
        # Formatação específica para DALL-E 3
        return f"Create an image of: {base_prompt}. Style: photorealistic, high quality, detailed."
        
    elif platform == 'gemini':
        # Configurações para Imagen 3
        return f"{base_prompt}, high resolution, detailed, aspect ratio {aspect_ratio}"
        
    else:
        return base_prompt

@prompt_bp.route('/random', methods=['GET'])
@cross_origin()
def generate_random():
    """Gera configurações aleatórias para inspiração"""
    import random
    
    random_config = {
        'subject': random.choice(SUBJECTS),
        'style': random.choice(STYLES),
        'composition': random.choice(COMPOSITIONS),
        'mood': random.choice(MOODS),
        'quality': random.choice(QUALITY_LEVELS),
        'aspectRatio': random.choice(ASPECT_RATIOS),
        'lighting': random.choice(LIGHTING_OPTIONS),
        'artist': random.choice(FAMOUS_ARTISTS),
        'camera': random.choice(CAMERAS),
        'creativity': random.randint(30, 90),
        'aiPlatform': random.choice(list(AI_PLATFORMS.keys()))
    }
    
    return jsonify(random_config)

@prompt_bp.route('/options', methods=['GET'])
@cross_origin()
def get_options():
    """Retorna todas as opções disponíveis para o frontend"""
    options = {
        'subjects': SUBJECTS,
        'styles': STYLES,
        'compositions': COMPOSITIONS,
        'aspectRatios': ASPECT_RATIOS,
        'moods': MOODS,
        'qualityLevels': QUALITY_LEVELS,
        'lightingOptions': LIGHTING_OPTIONS,
        'famousArtists': FAMOUS_ARTISTS,
        'cameras': CAMERAS,
        'aiPlatforms': AI_PLATFORMS
    }
    
    return jsonify(options)

